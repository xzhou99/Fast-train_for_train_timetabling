The open source codes are released to speed up the research in dynamic railway traffic management field.

Reference: Simultaneous train rerouting and rescheduling on an N-track network: A cumulative flow count based model reformulation. Submitted for publication in Transportation Research Part B.